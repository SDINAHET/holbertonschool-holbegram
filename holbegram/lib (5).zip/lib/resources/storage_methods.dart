// import 'dart:typed_data';
// import 'package:firebase_storage/firebase_storage.dart';
// import 'package:uuid/uuid.dart';

// class StorageMethods {
//   final FirebaseStorage _storage = FirebaseStorage.instance;
//   final Uuid _uuid = const Uuid();

//   Future<String> uploadImageToStorage({
//     required Uint8List file,
//     required String uid,
//   }) async {
//     final String id = _uuid.v4();
//     final ref = _storage.ref().child('posts').child(uid).child('$id.jpg');

//     final uploadTask = await ref.putData(file);
//     return await uploadTask.ref.getDownloadURL();
//   }
// }

// import 'dart:typed_data';
// import 'package:firebase_storage/firebase_storage.dart';
// import 'package:uuid/uuid.dart';

// class StorageMethods {
//   final FirebaseStorage _storage = FirebaseStorage.instance;
//   final Uuid _uuid = const Uuid();

//   Future<String> uploadImageToStorage({
//     required Uint8List file,
//     required String uid,
//   }) async {
//     final String id = _uuid.v4();
//     final Reference ref =
//         _storage.ref().child('posts').child(uid).child('$id.jpg');

//     final TaskSnapshot snap = await ref.putData(
//       file,
//       SettableMetadata(contentType: 'image/jpeg'),
//     );

//     final String url = await snap.ref.getDownloadURL();
//     return url;
//   }
// }

import 'dart:typed_data';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:uuid/uuid.dart';

class StorageMethods {
  final FirebaseStorage _storage = FirebaseStorage.instance;
  final Uuid _uuid = const Uuid();

  /// Upload image générique
  Future<String> uploadImageToStorage({
    required Uint8List file,
    required String uid,
  }) async {
    final String id = _uuid.v4();
    final Reference ref =
        _storage.ref().child('posts').child(uid).child('$id.jpg');

    final TaskSnapshot snap = await ref.putData(
      file,
      SettableMetadata(contentType: 'image/jpeg'),
    );

    return await snap.ref.getDownloadURL();
  }

  /// Alias pour AddImage (évite les erreurs)
  Future<String> uploadPostImage({
    required Uint8List file,
    required String uid,
  }) async {
    return uploadImageToStorage(file: file, uid: uid);
  }
}
