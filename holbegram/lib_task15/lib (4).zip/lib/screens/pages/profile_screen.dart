// import 'package:flutter/material.dart';

// class Profile extends StatelessWidget {
//   const Profile({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return const Scaffold(body: Center(child: Text('Profile')));
//   }
// }


import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final _auth = FirebaseAuth.instance;

  Future<void> _logout() async {
    try {
      await _auth.signOut();

      if (!mounted) return;

      // ✅ Navigation "safe" : revient au premier écran puis redirige vers login (si route existe)
      // Si tu n'as pas de route nommée, remplace par ton widget login.
      Navigator.of(context).popUntil((route) => route.isFirst);
      // Exemple si tu as une route "/login" :
      // Navigator.of(context).pushReplacementNamed('/login');
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Logout error: $e")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = _auth.currentUser;

    if (user == null) {
      return const Scaffold(
        backgroundColor: Colors.white,
        body: Center(child: Text("You must be logged in")),
      );
    }

    final uid = user.uid;

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        title: const Text(
          "Profile",
          style: TextStyle(
            fontFamily: "Billabong",
            fontSize: 32,
            color: Colors.black,
          ),
        ),
        actions: [
          IconButton(
            tooltip: "Logout",
            icon: const Icon(Icons.logout, color: Colors.black),
            onPressed: _logout,
          ),
        ],
      ),
      body: StreamBuilder<DocumentSnapshot>(
        stream: FirebaseFirestore.instance.collection('users').doc(uid).snapshots(),
        builder: (context, userSnap) {
          if (userSnap.hasError) {
            return Center(child: Text("Error: ${userSnap.error}"));
          }
          if (!userSnap.hasData || !userSnap.data!.exists) {
            return const Center(child: CircularProgressIndicator());
          }

          final data = userSnap.data!.data() as Map<String, dynamic>;

          final String username = (data['username'] ?? user.email ?? 'user').toString();
          final String bio = (data['bio'] ?? '').toString();
          final String photoUrl = (data['photoUrl'] ?? '').toString();

          final List followers = (data['followers'] is List) ? data['followers'] as List : [];
          final List following = (data['following'] is List) ? data['following'] as List : [];

          return Column(
            children: [
              const SizedBox(height: 10),

              // Header profile (avatar + username + bio + stats)
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Avatar
                    Container(
                      width: 86,
                      height: 86,
                      decoration: const BoxDecoration(shape: BoxShape.circle),
                      clipBehavior: Clip.antiAlias,
                      child: (photoUrl.isEmpty || !photoUrl.startsWith('http'))
                          ? Container(
                              color: const Color(0xFFF2F2F2),
                              child: const Icon(Icons.person, size: 45, color: Colors.grey),
                            )
                          : Image.network(
                              photoUrl,
                              fit: BoxFit.cover,
                              errorBuilder: (_, __, ___) => Container(
                                color: const Color(0xFFF2F2F2),
                                child: const Icon(Icons.person, size: 45, color: Colors.grey),
                              ),
                            ),
                    ),
                    const SizedBox(width: 16),

                    // Username + Bio + Stats
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            username,
                            style: const TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w800,
                              color: Colors.black,
                            ),
                          ),
                          const SizedBox(height: 6),
                          if (bio.isNotEmpty)
                            Text(
                              bio,
                              style: const TextStyle(color: Colors.black54),
                            ),
                          const SizedBox(height: 14),

                          // Stats row
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              _StatBox(
                                label: "Posts",
                                // on calcule via StreamBuilder plus bas (compte des posts)
                                child: StreamBuilder<QuerySnapshot>(
                                  stream: FirebaseFirestore.instance
                                      .collection('posts')
                                      .where('uid', isEqualTo: uid)
                                      .snapshots(),
                                  builder: (context, snap) {
                                    if (!snap.hasData) return const Text("0");
                                    return Text(
                                      "${snap.data!.docs.length}",
                                      style: const TextStyle(
                                        fontWeight: FontWeight.w800,
                                        fontSize: 16,
                                      ),
                                    );
                                  },
                                ),
                              ),
                              _StatBox(
                                label: "Followers",
                                child: Text(
                                  "${followers.length}",
                                  style: const TextStyle(
                                    fontWeight: FontWeight.w800,
                                    fontSize: 16,
                                  ),
                                ),
                              ),
                              _StatBox(
                                label: "Following",
                                child: Text(
                                  "${following.length}",
                                  style: const TextStyle(
                                    fontWeight: FontWeight.w800,
                                    fontSize: 16,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 16),
              const Divider(height: 1, color: Color(0xFFEAEAEA)),
              const SizedBox(height: 10),

              // Grid images (posts du user)
              Expanded(
                child: StreamBuilder<QuerySnapshot>(
                  stream: FirebaseFirestore.instance
                      .collection('posts')
                      .where('uid', isEqualTo: uid)
                      .orderBy('datePublished', descending: true)
                      .snapshots(),
                  builder: (context, postSnap) {
                    if (postSnap.hasError) {
                      return Center(child: Text("Error: ${postSnap.error}"));
                    }
                    if (!postSnap.hasData) {
                      return const Center(child: CircularProgressIndicator());
                    }

                    final docs = postSnap.data!.docs;

                    if (docs.isEmpty) {
                      return const Center(child: Text("No posts yet"));
                    }

                    return GridView.builder(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                      itemCount: docs.length,
                      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 3,
                        crossAxisSpacing: 6,
                        mainAxisSpacing: 6,
                        childAspectRatio: 1,
                      ),
                      itemBuilder: (context, index) {
                        final post = docs[index].data() as Map<String, dynamic>;
                        final url = (post['postUrl'] ?? '').toString();

                        return ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: (url.isEmpty || !url.startsWith('http'))
                              ? Container(
                                  color: const Color(0xFFF2F2F2),
                                  child: const Icon(Icons.image, color: Colors.grey),
                                )
                              : Image.network(
                                  url,
                                  fit: BoxFit.cover,
                                  errorBuilder: (_, __, ___) => Container(
                                    color: const Color(0xFFF2F2F2),
                                    child: const Icon(Icons.image, color: Colors.grey),
                                  ),
                                  loadingBuilder: (context, child, progress) {
                                    if (progress == null) return child;
                                    return Container(
                                      color: const Color(0xFFF2F2F2),
                                      child: const Center(
                                        child: SizedBox(
                                          width: 18,
                                          height: 18,
                                          child: CircularProgressIndicator(strokeWidth: 2),
                                        ),
                                      ),
                                    );
                                  },
                                ),
                        );
                      },
                    );
                  },
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _StatBox extends StatelessWidget {
  final String label;
  final Widget child;

  const _StatBox({
    required this.label,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        child,
        const SizedBox(height: 2),
        Text(
          label,
          style: const TextStyle(
            color: Colors.black54,
            fontSize: 12,
          ),
        ),
      ],
    );
  }
}
